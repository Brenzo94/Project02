<<<<<<< HEAD
#!/bin/bash

=======
#Project02
>>>>>>> 7e99e1f247c036e4b80a35b3a2608ebb1a3dcc27
date
pwd
ls
